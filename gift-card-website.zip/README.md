# GiftCard Maker

A simple static gift-card website.

## Files
- index.html — page structure
- style.css — design
- script.js — live preview, download and share-link functionality

## Run it
Open `index.html` in a browser.

## Put it online
Upload all three files to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages. Your site will then have a public URL such as:

https://your-site.example/

The Share Card button creates a URL containing the card details after `#card=`. No database is required for this basic version.

## Important
This version creates a digital gift-card DESIGN. It does not create real monetary/store gift-card balances, payment processing, or redeemable codes. Those features require a secure backend and, for real-value cards, integration with a legitimate payment/gift-card provider.

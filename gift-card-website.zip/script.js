const $ = id => document.getElementById(id);

const fields = ["recipient", "sender", "amount", "message", "theme"];

function updatePreview() {
  $("previewRecipient").textContent = $("recipient").value.trim() || "Your recipient";
  $("previewSender").textContent = $("sender").value.trim() || "From you";
  $("previewMessage").textContent =
    $("message").value.trim() || "Your special message will appear here.";

  const amount = $("amount").value.trim();
  $("previewAmount").textContent = amount ? "₦" + Number(amount).toLocaleString("en-NG") : "Gift";

  $("card").className = "gift-card " + $("theme").value;
}

fields.forEach(id => $(id).addEventListener("input", updatePreview));
$("theme").addEventListener("change", updatePreview);
updatePreview();

function safeText(value) {
  return String(value || "").replace(/[<>&"]/g, c => ({
    "<":"&lt;", ">":"&gt;", "&":"&amp;", '"':"&quot;"
  }[c]));
}

// Creates a self-contained URL using URL-safe encoded data.
// This is suitable for sharing the card details without a database.
function makeShareUrl() {
  const data = {
    recipient: $("recipient").value.trim(),
    sender: $("sender").value.trim(),
    amount: $("amount").value.trim(),
    message: $("message").value.trim(),
    theme: $("theme").value
  };
  const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  return location.href.split("#")[0] + "#card=" + encoded;
}

function loadFromUrl() {
  if (!location.hash.startsWith("#card=")) return;
  try {
    const encoded = location.hash.slice(6);
    const data = JSON.parse(decodeURIComponent(escape(atob(encoded))));
    ["recipient","sender","amount","message","theme"].forEach(k => {
      if (data[k] !== undefined) $(k).value = data[k];
    });
    updatePreview();
  } catch (_) {}
}
loadFromUrl();

$("shareBtn").addEventListener("click", async () => {
  const url = makeShareUrl();
  try {
    await navigator.clipboard.writeText(url);
    $("status").textContent = "Share link copied to your clipboard.";
  } catch (_) {
    window.prompt("Copy this gift-card link:", url);
  }
});

$("downloadBtn").addEventListener("click", () => {
  const card = $("card");
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 750;
  const ctx = canvas.getContext("2d");

  const theme = $("theme").value;
  const gradients = {
    sunset: ["#ff7a59", "#7a2cff"],
    ocean: ["#0077b6", "#00b4d8"],
    forest: ["#176b45", "#9ac53d"],
    royal: ["#432371", "#faae7b"]
  };
  const [a,b] = gradients[theme];
  const g = ctx.createLinearGradient(0, 0, 1200, 750);
  g.addColorStop(0, a); g.addColorStop(1, b);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 1200, 750);

  ctx.fillStyle = "rgba(255,255,255,.14)";
  ctx.beginPath(); ctx.arc(1050, 100, 180, 0, Math.PI*2); ctx.fill();

  ctx.fillStyle = "white";
  ctx.font = "800 28px system-ui";
  ctx.fillText("GIFT CARD", 65, 70);
  ctx.font = "40px system-ui";
  ctx.fillText("🎁", 1080, 72);

  ctx.globalAlpha = .8;
  ctx.font = "700 20px system-ui";
  ctx.fillText("FOR", 65, 230);
  ctx.globalAlpha = 1;
  ctx.font = "800 72px system-ui";
  ctx.fillText($("recipient").value.trim() || "Your recipient", 65, 310);

  ctx.font = "28px system-ui";
  const msg = $("message").value.trim() || "Your special message will appear here.";
  wrapText(ctx, msg, 65, 365, 980, 38);

  ctx.font = "800 34px system-ui";
  const amount = $("amount").value.trim();
  ctx.fillText(amount ? "₦" + Number(amount).toLocaleString("en-NG") : "Gift", 65, 515);

  ctx.font = "700 20px system-ui";
  ctx.fillText("WITH LOVE", 65, 690);
  ctx.textAlign = "right";
  ctx.fillText($("sender").value.trim() || "From you", 1135, 690);
  ctx.textAlign = "left";

  const link = document.createElement("a");
  link.download = "gift-card.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
  $("status").textContent = "Gift card downloaded.";
});

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  for (const word of words) {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      line = word;
      y += lineHeight;
    } else line = test;
  }
  if (line) ctx.fillText(line, x, y);
}
